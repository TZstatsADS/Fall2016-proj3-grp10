#Train-error.R#

library(gbm)
library(h2o)
library(xgboost)
library(data.table)

###Data input#
Sift_test<-read.csv("Sift_test.csv")
Sift_test<-t(Sift_test)
label<-read.csv("label.csv")
Features<-read.csv("Features.csv")
Features<-na.omit(Features[,-1])
Features<-t(Features)
Sift_test_raw<-cbind(Sift_test,label)
Sift_test_advance<-cbind(Features,label)


###Cross-Validation###
ind<-vector("list",length=5)
ind[[1]]<-sample(2000,400)
ind[[2]]<-sample(c(1:2000)[-ind[[1]]],400)
ind[[3]]<-sample(c(1:2000)[-c(ind[[1]],ind[[2]])],400)
ind[[4]]<-sample(c(1:2000)[-c(ind[[1]],ind[[2]],ind[[3]])],400)
ind[[5]]<-c(1:2000)[-c(ind[[1]],ind[[2]],ind[[3]],ind[[4]])]


###GBM+SIFT###
start.time<-Sys.time()
Train_gbm_sift<-vector(length=5)
for(i in 1:5)
{ s_test<-Sift_test_raw[ind[[i]],]
  s_train<-Sift_test_raw[-ind[[i]],]
  fit_gb<-gbm(label~.,data=data.frame(s_train),distribution="bernoulli",n.trees=100,shrinkage=1,interaction.depth=2)
  test_gbm<-predict(fit_gb,newdata=data.frame(s_test[,c(1:5000)]),n.trees=100)
  for(j in 1:length(test_gbm))
  {if(test_gbm[j]>=0)
  {test_gbm[j]=1}
    else{test_gbm[j]=0}}
  Train_gbm_sift[i]<-sum(test_gbm==s_test[,5001])/length(test_gbm)}
Train_gbm_sift_acc<-mean(Train_gbm_sift)
end.time<-Sys.time()
time1<-end.time-start.time

###GBM+Features#
start.time<-Sys.time()
Train_gbm_advanced<-vector(length=5)
for(i in 1:5)
{ s_test<-Sift_test_advance[ind[[i]],]
  s_train<-Sift_test_advance[-ind[[i]],]
  fit_gb<-gbm(label~.,data=data.frame(s_train),distribution="bernoulli",n.trees=100,shrinkage=1,interaction.depth=2)
  test_gbm<-predict(fit_gb,newdata=data.frame(s_test[,c(1:5033)]),n.trees=100)
  for(j in 1:length(test_gbm))
  {if(test_gbm[j]>=0)
   {test_gbm[j]=1}
   else{test_gbm[j]=0}}
  Train_gbm_advanced[i]<-sum(test_gbm==s_test[,5034])/length(test_gbm)}
Train_gbm_advanced_acc<-mean(Train_gbm_advanced)
end.time<-Sys.time()
time2<-end.time-start.time

###New Model+Features#
start.time<-Sys.time()
Train_new_advanced<-vector(length=5)
localH2O = h2o.init(ip = "localhost", port = 54321, startH2O = TRUE)
for(i in 1:5)
{ s_test<-Sift_test_advance[ind[[i]],]
  s_train<-Sift_test_advance[-ind[[i]],]
  #GBM#
  fit_gb<-gbm(label~.,data=data.frame(s_train),distribution="bernoulli",n.trees=100,shrinkage=1,interaction.depth=2)
  test_gbm<-predict(fit_gb,newdata=data.frame(s_test[,c(1:5033)]),n.trees=100)
  for(j in 1:length(test_gbm))
  {if(test_gbm[j]>=0)
  {test_gbm[j]=1}
    else{test_gbm[j]=0}}
  #deeplearning: tanh#
  dat_h2o<- as.h2o(data.frame(s_train))
  test_h2o<-as.h2o(data.frame(s_test[,c(1:5033)]))
  model_tanh <- 
    h2o.deeplearning(x = 1:5033,  # column numbers for predictors
                     y = 5034,   # column number for label
                     dat_h2o, # data in H2O format
                     activation = "TanhWithDropout", 
                     input_dropout_ratio = 0.2, # % of inputs dropout
                     hidden_dropout_ratios = c(0.5,0.5,0.5,0.5,0.5), # % for nodes dropout
                     balance_classes = FALSE, 
                     hidden = c(50,50,50,50,50), # five layers of 50 nodes
                     epochs = 100)
  h2o_tanh_yhat<-h2o.predict(model_tanh,test_h2o)
  test_dp_tanh<-as.data.frame(h2o_tanh_yhat)
  test_dp_tanh<-test_dp_tanh[,1]
  for(j in 1:length(test_dp_tanh))
  {if(test_dp_tanh[j]>=0.5)
  {test_dp_tanh[j]=1}
   else{test_dp_tanh[i]=0}}
  #deeplearning: Maxout#
  model_maxout<-
    h2o.deeplearning(x = 1:5033,  # column numbers for predictors
                     y = 5034,   # column number for label
                     dat_h2o, # data in H2O format
                     activation = "MaxoutWithDropout", 
                     input_dropout_ratio = 0.2, # % of inputs dropout
                     hidden_dropout_ratios = c(0.5,0.5,0.5,0.5,0.5), # % for nodes dropout
                     balance_classes = FALSE, 
                     hidden = c(50,50,50,50,50), # five layers of 50 nodes
                     epochs = 100)
  h2o_maxout_yhat<-h2o.predict(model_maxout,test_h2o)
  test_dp_maxout<-as.data.frame(h2o_maxout_yhat)
  test_dp_maxout<-test_dp_maxout[,1]
  for(j in 1:length(test_dp_maxout))
  {if(test_dp_maxout[j]>=0.5)
  {test_dp_maxout[j]=1}
   else{test_dp_maxout[j]=0}}
  #adaboost#
  fit_ada<-gbm(label~.,data=data.frame(s_train),distribution="adaboost",n.trees=100,shrinkage=1)
  test_ada<-predict(fit_ada,newdata=data.frame(s_test[,c(1:5033)]),n.trees=100)
  for(j in 1:length(test_ada))
  {if(test_ada[j]>=0)
  {test_ada[j]=1}
    else{test_ada[j]=0}}
  #xgboost#
  h<-sample(nrow(s_train),200)
  dval<-xgb.DMatrix(data=s_train[h,1:(dim(s_train)[2]-1)],
                    label=s_train[h,dim(s_train)[2]], missing=NA)
  dtrain<-xgb.DMatrix(data=s_train[-h,1:(dim(s_train)[2]-1)],
                      label=s_train[-h,dim(s_train)[2]], missing=NA)
  #watchlist<-list(val=dval,train=dtrain)
  param <- list(  objective           = "binary:logistic", 
                  booster             = "gbtree",
                  eta                 = 0.025, 
                  max_depth           = 6, 
                  subsample           = 0.7, 
                  colsample_bytree    = 0.9, 
                  # eval_metric         = "rmse",
                  metrics={'error'},
                  min_child_weight    = 6
  )
  
  clf <- xgb.train(data = dtrain, 
                   params               = param, 
                   nrounds              = 1000, #300
                   verbose              = 0,#2
                   #                 watchlist            = watchlist,
                   early.stop.round     = NULL, 
                   maximize            = FALSE,
                   print.every.n        = 1
  )
  test_xg<-predict(clf,s_test[,-label],
                           ntreelimit =clf$bestInd, missing=NA)
  for(j in 1:length(test_xg))
  {if(test_xg[j]>=0.5)
  {test_xg[j]=1}
    else{test_xg[j]=0}}
  #majority vote#
  majority<-test_gbm+test_dp_tanh+test_dp_maxout+test_ada+test_xg
  test_majority<-vector(length=length(majority))
  for(j in 1:length(majority))
  { if(majority[j]>=3)
  {test_majority[j]=1}
    else{test_majority[j]=0}}
  Train_new_advanced[i]<-sum(test_majority==s_test[,5034])/length(test_majority)
}
Train_new_advanced_acc<-mean(Train_new_advanced)
end.time<-Sys.time()
time3<-end.time-start.time

###save results#
times<-c(as.numeric(time1),as.numeric(time2),as.numeric(time3))
acc<-c(Train_gbm_sift_acc,Train_gbm_advanced_acc,Train_new_advanced_acc)
results<-rbind(acc,times)
colnames(results)<-c("GBM+SIFT","GBM+Features","Advanced Model+Features")
rownames(results)<-c("Accuracy","time-cost(mins)")
write.csv(results,"Train_error.csv")
